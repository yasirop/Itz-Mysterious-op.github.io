exports.PREFIX = "k!";
exports.OWNER_ID = "739440353551319083";
exports.Owner_Name = "Itz Mysterious op#2064";